from .models import *
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.viewsets import ModelViewSet
from listing.models import Product, Offer
from .serializers import OrderSerializer,ReviewSerializer,OrderShortSerializer
from rest_framework import status
from .filters import OrderFilter
from rest_framework.decorators import action
from authentication.models import SellerProfile
# Create your views here.


class OrderView(ModelViewSet):
    queryset = Order.objects.all()
    serializer_class = OrderSerializer
    http_method_names = ['get', 'post', 'patch']
    permission_classes = [IsAuthenticated, ]
    filterset_class = OrderFilter
    error_status = status.HTTP_400_BAD_REQUEST
    output_data_for_error = {"message": None}

    def list(self, request):
        if "product_id" in list(request.query_params):
            product_id = request.query_params['product_id']
            product = Product.objects.filter(id=product_id).first()
            if not product:
                self.output_data_for_error['message'] = "Product with this id does not exist"
                return Response(self.output_data_for_error, self.error_status)
            if product.created_by.user != request.user:
                self.output_data_for_error['message'] = "Not your product."
                return Response(self.output_data_for_error, self.error_status)
            orders = self.queryset.filter(product=product)
        else:
            orders = self.queryset.filter(buyer=request.user)
        orders = self.filter_queryset(orders)
        serializer = OrderShortSerializer(orders, many=True)
        return Response(serializer.data)

    @action(detail=False,methods=['GET'])
    def asSeller(self,request):
        orders = Order.objects.filter(product__created_by__user=request.user)
        orders = self.filter_queryset(orders)
        serializer = OrderShortSerializer(orders,many=True)
        return Response(serializer.data)

    def retrieve(self, request, pk):
        order = Order.objects.filter(id=pk).first()
        if not order:
            self.output_data_for_error['message'] = "No order exists with the given order id"
            return Response(self.output_data_for_error, self.error_status)

        if request.user != order.product.created_by.user and request.user != order.buyer:
            self.output_data_for_error['message'] = "You are not authorized to see this order"
            return Response(self.output_data_for_error, self.error_status)

        serializer = OrderSerializer(order,many=False)
        return Response(serializer.data)
        

    def partial_update(self, request, pk=None):
        return Response({"message": "Partial update method disabled"},
                        status=status.HTTP_400_BAD_REQUEST)

    def create(self, request):
        offer_id, is_to_ship = None, None
        product_id = request.data.get("product_id")
        status = request.data.get("status")
        buyer = request.user

        if status:
            self.output_data_for_error['message'] = "You must not provide a status here as the default status is already set to pending."
            return Response(self.output_data_for_error, self.error_status)
        if not product_id:
            self.output_data_for_error['message'] = "Please provide a product id to place an offer on."
            return Response(self.output_data_for_error, self.error_status)

        product = Product.objects.filter(id=product_id).first()
        if not product:
            self.output_data_for_error['message'] = "Product with this id does not exist"
            return Response(self.output_data_for_error, self.error_status)

        if Order.objects.filter(product=product).first():
            self.output_data_for_error['message'] = "An order already exists on this product"
            return Response(self.output_data_for_error, self.error_status)

        product_price = OrderAmount.objects.create(product=product.price)
        order = Order.objects.create(
            product=product, buyer=buyer, price=product_price)

        if "is_to_ship" in list(request.POST):
            is_to_ship = request.POST['is_to_ship']
            order.is_to_ship = is_to_ship

        if "offer_id" in list(request.POST):
            offer = Offer.objects.filter(id=request.POST['offer_id']).first()
            if not offer:
                self.output_data_for_error['message'] = "Offer with the given id does not exist"
                order.delete()
                return Response(self.output_data_for_error, self.error_status)
            if not offer.created_by == buyer:
                self.output_data_for_error['message'] = "You did not create this offer"
                order.delete()
                return Response(self.output_data_for_error, self.error_status)
            if not offer.is_approved:
                self.output_data_for_error['message'] = "This offer is not approved yet"
                order.delete()
                return Response(self.output_data_for_error, self.error_status)
            offer_price = OrderAmount.objects.create(product=offer.price)
            order.offer = offer
            order.price = offer_price
        order.save()
        serializer = OrderSerializer(order)
        return Response(serializer.data)

    @action(detail=True, methods=['patch'])
    def confirm(self, request, pk):
        order = Order.objects.filter(id=pk).first()

        if not order:
            self.output_data_for_error['message'] = "Order with this id does not exist"
            return Response(self.output_data_for_error, self.error_status)

        if order.product.created_by.user != request.user:
            self.output_data_for_error['message'] = "You are not the seller of the product of the order"
            return Response(self.output_data_for_error, self.error_status)

        

        order.status = 'CONFIRMED'
        serializer = OrderSerializer(
            order, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()

        if order.offer:
            order.offer.is_order_placed=True
            order.offer.save()
            
        return Response(serializer.data)

    @action(detail=True, methods=['patch'])
    def status_update(self, request, pk):
        destination_status = request.data.get("status")
        order = Order.objects.filter(id=pk).first()
        if not order:
            self.output_data_for_error['message'] = "No order exists with the given order id"
            return Response(self.output_data_for_error, self.error_status)
        if not destination_status:
            self.output_data_for_error["message"] = "You must provide a status"
            return Response(self.output_data_for_error, self.error_status)
        if order.status == destination_status:
            self.output_data_for_error["message"] = "The status is already what you are trying to update"
            return Response(self.output_data_for_error, self.error_status)

        is_allowed = order.isAllowed(request.user, destination_status)
        if not is_allowed:
            self.output_data_for_error["message"] = "Permission not allowed by isAllowedmethod"
            return Response(self.output_data_for_error, self.error_status)

        serializer = OrderSerializer(order, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)


class ReviewView(ModelViewSet):
    queryset = Review.objects.all()
    serializer_class = ReviewSerializer
    http_method_names = ['get', 'post']
    permission_classes = [IsAuthenticated, ]
    error_status = status.HTTP_400_BAD_REQUEST
    output_data_for_error = {"message": None}

    def list(self,request):
        seller_id = request.query_params.get("seller_id")
        if not seller_id:
            self.output_data_for_error['message'] = "Please provide a seller id to see the reviews"
            return Response(self.output_data_for_error, self.error_status)
        
        seller_profile = SellerProfile.objects.filter(pk=seller_id).first()
        if not seller_profile:
            self.output_data_for_error['message'] = "Seller Profile with this id does not exist"
            return Response(self.output_data_for_error, self.error_status)

        reviews = self.queryset.filter(order__product__created_by__user=request.user)
        serializer = self.serializer_class(reviews,many=True)
        return Response(serializer.data)
    
    def retrieve(self,request):
        return Response({"message": "Retreive method disabled"},
                        status=status.HTTP_400_BAD_REQUEST)

    def create(self, request):
        order_id = request.data.get("order_id")
        description = request.data.get("description")
        stars = request.data.get("stars")

        if not order_id:
            self.output_data_for_error['message'] = "Please provide a order id to place a review on."
            return Response(self.output_data_for_error, self.error_status)
        if not description:
            self.output_data_for_error['message'] = "Please provide a description to place a review on."
            return Response(self.output_data_for_error, self.error_status)
        if not stars:
            self.output_data_for_error['message'] = "Please provide a stars to place a review on."
            return Response(self.output_data_for_error, self.error_status)
        
        if int(stars) >= 6 or int(stars) <1:
            self.output_data_for_error['message'] = "You can only have a value in between 1 and 5 for the stars."
            return Response(self.output_data_for_error, self.error_status)

        order = Order.objects.filter(pk=order_id).first()
        if not order:
            self.output_data_for_error['message'] = "Order with this id does not exist"
            return Response(self.output_data_for_error, self.error_status)

        if order.status != "COMPLETED":
            self.output_data_for_error['message'] = "This order is not completed so you can post a review on this order."
            return Response(self.output_data_for_error, self.error_status)
        
        if request.user != order.buyer:
            self.output_data_for_error['message'] = "You are not the buyer so you can not post a review here."
            return Response(self.output_data_for_error, self.error_status)
        
        review = Review(order=order,description=description,stars=stars)
        review.save()
        serializer = ReviewSerializer(review,many=False)
        return Response(serializer.data)
