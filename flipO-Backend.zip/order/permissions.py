from rest_framework.permissions import BasePermission, SAFE_METHODS
from .models import Order
from authentication.models import User
from listing.models import Product, Offer


class OrderPermission(BasePermission):
    def has_permission(self, request, view):
        if "buyer_id" in list(request.query_params):
            buyer_id = request.query_params['buyer_id']
            buyer = User.objects.get(id=buyer_id)
            if request.user == buyer:
                return True
        return False


    