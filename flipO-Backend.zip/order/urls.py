from django.urls import path, include
from .views import *
from rest_framework.routers import DefaultRouter

router = DefaultRouter(trailing_slash=False)
router.register('orders', OrderView, basename='orders')
router.register('reviews', ReviewView, basename='reviews')


urlpatterns = [
    path("", include(router.urls)),
]
