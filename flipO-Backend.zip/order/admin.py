from django.contrib import admin
from .models import Order,OrderAmount,Review
# Register your models here.

@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ('id','product','buyer', 'price', 'offer',
                    'status',)

@admin.register(OrderAmount)
class OrderAmountAdmin(admin.ModelAdmin):
    list_display = ('id','product', 'shipping', 'pick',
                    'discount',)

admin.site.register(Review)