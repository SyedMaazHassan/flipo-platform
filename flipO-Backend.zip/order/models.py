from django.db import models
from authentication.models import User
from listing.models import Product, Offer
from django.core.validators import MinValueValidator, MaxValueValidator
# Create your models here.

# python manage.py makemigrations
# python manage.py migrate
# python manage.py runserver

class OrderAmount(models.Model):
    product = models.FloatField() 
    shipping = models.FloatField(default=0)
    pick = models.FloatField(default=0)
    discount = models.FloatField(default=0)

    def getTotal(self):
        total = self.product
        if self.shipping:
            total += self.shipping
        if self.pick:
            total += self.pick
        if self.discount:
            total -= self.discount
        return total

    def __str__(self):
        return str(self.getTotal())


class Order(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    is_to_ship = models.BooleanField(default=False)
    buyer = models.ForeignKey(User, on_delete=models.CASCADE)
    offer = models.ForeignKey(
        Offer, on_delete=models.CASCADE, null=True, blank=True)
    price = models.ForeignKey(OrderAmount, on_delete=models.CASCADE)
    status = models.CharField(max_length=150, default='PENDING')
    address = models.CharField(max_length=255, default="Address 123")
    created_at = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    updated_at = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    

    def getNextStatus(self):
        current_and_destination_index = {
            'PENDING':0,
            'CONFIRMED':1,
            'READY':2,
            'SHIPPED':3,
            'COMPLETED':4,
            'REVIEWED':5,
            'CANCELLED':6
        }
        keys_list = list(current_and_destination_index.keys())
        current_state = current_and_destination_index[self.status]

        if current_state > 4:
            return None

        next_state = current_state + 1
        return keys_list[next_state].title()
        

    def getDeliveryMode(self):
        if self.is_to_ship:
            return "Shipping"
        return "Pick up"

    # a history field # json object #
    def getSeller(self):
        return self.product.created_by.user

    def __str__(self):
        return str(self.product.created_by)

    def set_price(self):
        if self.offer:
            self.price = OrderAmount.objects.create(product=self.offer.price)
        self.price = OrderAmount.objects.create(product=self.product.price)

    def is_transition_allowed(self,destination_status):
        permission_to_transit = False
        if self.status == "PENDING" and destination_status == "CONFIRMED": 
            permission_to_transit = True
        if self.status == "CONFIRMED" and (destination_status == "READY" or destination_status == "CANCELLED"):
            permission_to_transit = True
        if self.status == 'READY' and (destination_status == "SHIPPED" or destination_status == "CANCELLED" or destination_status == "COMPLETED"):
            permission_to_transit = True
        if self.status == 'SHIPPED' and (destination_status == "CANCELLED" or destination_status == "COMPLETED"):
            permission_to_transit = True
        if self.status == "COMPLETED" and destination_status == 'REVIEWED':
            permission_to_transit = True
        return permission_to_transit

    def set_status(self,destination_status):
        self.status = destination_status

    def is_action_allowed(self,current_user):
        permission=False
        if current_user == self.product.created_by.user or current_user==self.buyer:
            permission = True
        return permission


    def isAllowed(self,current_user,destination_status):
        current_and_destination_index = {
            'PENDING':0,
            'CONFIRMED':1,
            'READY':2,
            'SHIPPED':3,
            'COMPLETED':4,
            'REVIEWED':5,
            'CANCELLED':6
        }
        current_state_index = current_and_destination_index[self.status]
        destination_state_index = current_and_destination_index[destination_status]
        if current_user == self.buyer:
            base_matrix = [
                [False, True, False, False, False, False, False],
                [False,	False, False, False, False,	False, True],
                [False,	False, False, False ,True,	False, True],
                [False,	False, False, False, True, False, True],
                [False,	False, False, False, False,	True, False],
                [False,	False, False, False, False,	False, False],
                [False,	False, False, False, False, False, False]
            ]
        elif current_user == self.product.created_by.user:
            base_matrix = [
                [False, False, False, False, False, False, False],
                [False,	False, True, False, False,	False, True],
                [False,	False, False, True ,True,	False, False],
                [False,	False, False, False, True, False, False],
                [False,	False, False, False, False,	False, False],
                [False,	False, False, False, False,	False, False],
                [False,	False, False, False, False, False, False]
            ]
        else:
            return False
        
        return base_matrix[current_state_index][destination_state_index]


class Review(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE)
    description = models.TextField()
    stars = models.IntegerField(validators=[MinValueValidator(1),
                                       MaxValueValidator(5)])

    def __str__(self):
        return f'{self.order}'