from .models import Order,OrderAmount,Review
from rest_framework import serializers
from listing.serializers import ProductSerializer, ProductShortSerializer
from authentication.serializers import UserShortProfile, UserContactProfile


class OrderAmountSerializer(serializers.ModelSerializer):
    total = serializers.FloatField(source = "getTotal")
    class Meta:
        model = OrderAmount
        fields = ['product',"pick","shipping","discount", "total"]


class OrderShortSerializer(serializers.ModelSerializer):
    buyer = UserShortProfile(many = False)
    product = ProductShortSerializer(many=False)
    price = OrderAmountSerializer(many=False)

    class Meta:
        model = Order
        fields = ['id', 'product', 'buyer', 'price', 'status', 'created_at']


class OrderSerializer(serializers.ModelSerializer):
    buyer = UserContactProfile(many = False)
    seller = UserContactProfile(source = 'getSeller')
    price = OrderAmountSerializer(many=False)
    product = ProductShortSerializer(many=False)
    delivery_mode = serializers.CharField(source = 'getDeliveryMode')
    next_state = serializers.CharField(source = 'getNextStatus')

    class Meta:
        model = Order
        fields = [
            'id', 
            'created_at',
            'status',
            'seller',
            'buyer',
            'product',
            'price',
            'delivery_mode',
            'address',
            'next_state',
            'offer' 
        ]


class ReviewSerializer(serializers.ModelSerializer):
    order = OrderSerializer(many=False)
    class Meta:
        model = Review
        fields = ["order","description","stars"]