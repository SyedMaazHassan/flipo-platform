from django.contrib import admin
from .models import Ticket,TicketResponse
# Register your models here.

class ResponseInline(admin.TabularInline):
    model = TicketResponse
    extra = 1
    can_delete = False
    can_add = True
    can_edit = False
    readonly_fields = fields = ("message", "sent_from", "created_at")

class TicketAdmin(admin.ModelAdmin):
    model = Ticket
    inlines = [ResponseInline] 
    list_display = [ "title", "status", "created_at","created_by","description"]
    search_fields = ["title"]


admin.site.register(Ticket,TicketAdmin)