from rest_framework import serializers
from .models import Ticket,TicketResponse

class TicketResponseSerializer(serializers.ModelSerializer):
    class Meta:
        model = TicketResponse
        fields = "__all__"

class TicketSerializer(serializers.ModelSerializer):
    responses = serializers.SerializerMethodField("get_responses")
    def get_responses(self,obj):
        resp = TicketResponse.objects.filter(ticket=obj)
        serializer = TicketResponseSerializer(resp,many=True)
        return serializer.data
        
    class Meta:
        model = Ticket
        fields = ["id",'title','assignee',"status","created_at","updated_at",'created_by','responses']
        
