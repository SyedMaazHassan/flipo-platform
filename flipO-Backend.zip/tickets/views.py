from django.shortcuts import render
from rest_framework.viewsets import ModelViewSet
from .serializers import TicketSerializer,TicketResponseSerializer
from rest_framework.permissions import IsAuthenticated
from .models import Ticket,TicketResponse
from rest_framework import status
from rest_framework.response import Response
from rest_framework.decorators import action

# Create your views here.
class TicketsView(ModelViewSet):
    queryset = Ticket.objects.all()
    http_method_names = ['get','post']
    permission_classes = [IsAuthenticated,]
    error_status = status.HTTP_400_BAD_REQUEST
    output_data_for_error = {"message": None}

    def list(self,request):
        tickets = self.queryset.filter(created_by=request.user)
        serializer = TicketSerializer(tickets,many=True)
        return Response(serializer.data)

    def retrieve(self, request,pk):
        ticket = Ticket.objects.filter(pk=pk).first()
        if not ticket:
            self.output_data_for_error['message'] = "Invalid Primary Key"
            return Response(self.output_data_for_error, self.error_status)
        if ticket.created_by != request.user:
            self.output_data_for_error['message'] = "You did not create this ticket"
            return Response(self.output_data_for_error, self.error_status)
        
       
        serializer = TicketSerializer(ticket)
        
        return Response(serializer.data)

    

    def create(self,request):
        title = request.data.get("title")
        description = request.data.get("description")
        

        if not title:
            self.output_data_for_error['message'] = "You must provide a title for the ticket"
            return Response(self.output_data_for_error, self.error_status)
        if not description:
            self.output_data_for_error['message'] = "You must provide a description for the ticket"
            return Response(self.output_data_for_error, self.error_status)

        # Checking if the current user already has 10 open tickets
        if len(Ticket.objects.filter(created_by=request.user,status="Open")) >=10:
            self.output_data_for_error['message'] = "You already have 10 open tickets so can not create anymore"
            return Response(self.output_data_for_error, self.error_status)

        ticket = Ticket.objects.create(title=title,created_by=request.user)
        ticket.save()
        serializer=TicketSerializer(ticket)
        return Response(serializer.data)


    @action(detail=True, methods=['post'])
    def response(self,request,pk):
        message = request.data.get("message")
        if not message:
            self.output_data_for_error['message'] = "You must provide a message"
            return Response(self.output_data_for_error, self.error_status)

        ticket = Ticket.objects.filter(id=pk).first()

        if not ticket:
            self.output_data_for_error['message'] = "Invalid Primary Key"
            return Response(self.output_data_for_error, self.error_status)
        
        if ticket.status == "Solved":
            self.output_data_for_error['message'] = "The status of this ticket is solved so you can not sent a response."
            return Response(self.output_data_for_error, self.error_status)

        if ticket.created_by != request.user:
            self.output_data_for_error['message'] = "You did not create this ticket"
            return Response(self.output_data_for_error, self.error_status)

        ticket_response = TicketResponse.objects.create(ticket=ticket,message=message,sent_from=request.user)
        ticket_response.save()
        return Response({"message":"Response sent successfully."})