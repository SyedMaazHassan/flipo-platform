from django.urls import path, include
from .views import *
from rest_framework.routers import DefaultRouter

router = DefaultRouter(trailing_slash=False)
router.register('tickets', TicketsView, basename='tickets')

urlpatterns = [
    path("", include(router.urls)),
]