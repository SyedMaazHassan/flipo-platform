from django.db import models
from authentication.models import User
# Create your models here.
class TicketStatus(models.TextChoices):
    OPEN = "Open"
    AWAITING_YOUR_REPLY = "Awaiting your reply"
    SOLVED = 'Solved'

class Ticket(models.Model):
    title = models.CharField(max_length=100)
    description = models.TextField()
    assignee = models.CharField(max_length=100,null=True,blank=True)
    status = models.CharField(max_length=25, choices=TicketStatus.choices, default=TicketStatus.OPEN)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(null=True,blank=True)
    created_by = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self):
        return self.title

class TicketResponse(models.Model):
    ticket = models.ForeignKey(Ticket, on_delete=models.CASCADE)
    message = models.TextField()
    sent_from = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.message

    class Meta:
        ordering = ("-created_at",)