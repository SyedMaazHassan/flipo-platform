from alerts.models import Notification


def sendNotification(subject, body, receiver, receiver_type, redirect_screen, redirect_api, username=None, product=None, order=False, offer=False):
    current_body = body
    notification = None
    if product:
        notification = Notification.objects.filter(product = product, receiver = receiver).first()


    if receiver_type == "seller":
        if notification:
            other = "other "
            counter = notification.counter
            if counter > 1:
                other = "others "
            new_body = f"{username} and {counter} {other}have submitted offers on your product '{product.title}'"
            notification.counter += 1
            notification.body = new_body
            notification.is_seen = False

        if not product or not notification:
            notification = Notification(
                product = product,
                subject = subject,
                body = body,
                receiver = receiver,
                redirect_screen = redirect_screen,
                redirect_api = redirect_api
            )
    else:
        notification = Notification(
            product = product,
            subject = subject,
            body = body,
            receiver = receiver,
            redirect_screen = redirect_screen,
            redirect_api = redirect_api
        )
        print("for buyer")

    if order or offer:
        if order:
            module = 'order'
            notification.order = order
        if offer:
            module = 'offer'
            notification.offer = offer

        # Step # 1 - saving in Database
        notification.module = module
        notification.save()

        # Step # 2 - send notification through firebase
        notification.pushNotify(current_body)

        # Step # 3 - send notification through socket django
        notification.socketNotify(current_body)

        return True
    else:
        return False