from django.urls import path
from .views import *
from rest_framework.routers import DefaultRouter
router = DefaultRouter(trailing_slash=False)
router.register('notifications', NotificationApi, basename='notifications')

urlpatterns = [
    # path('', index, name="index"),
    path('firebase-messaging-sw.js',showFirebaseJS,name="show_firebase_js"),
    path('device', DeviceApi.as_view(), name="device"),
    # path('emailAuth/login', LoginApiView.as_view(), name="login"),
    # path('logout', LogoutApiView.as_view(), name="logout"),
    # path('token/refresh', TokenRefreshView.as_view(), name='token_refresh'),
    # path('token/verify', TokenVerifyView.as_view(), name='token_verify'),

]

urlpatterns += router.urls