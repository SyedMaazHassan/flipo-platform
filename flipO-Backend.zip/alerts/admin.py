from django.contrib import admin
from .models import *
# Register your models here.


class DeviceRegistrationAdmin(admin.ModelAdmin):
    list_display = ("id", "reg_id")

class NotificationAdmin(admin.ModelAdmin):
    list_display = ('module','receiver', 'body','is_seen', 'created_at')

admin.site.register(Notification, NotificationAdmin)
admin.site.register(DeviceRegistration, DeviceRegistrationAdmin)
