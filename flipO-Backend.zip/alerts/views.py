from django.shortcuts import render
from rest_framework.permissions import IsAuthenticatedOrReadOnly, IsAuthenticated
from .serializers import *
from rest_framework.views import APIView
from rest_framework.response import Response
from django.http import HttpResponse
from rest_framework import status, viewsets, generics
from rest_framework.decorators import api_view, action


# Create your views here.
class NotificationApi(viewsets.ModelViewSet):
    permission_classes = (IsAuthenticated,)
    serializer_class = NotificationSerializer
    queryset = Notification.objects.all()
    http_method_names = ['get', 'post']

    def list(self, request):
        notifications = self.queryset.filter(receiver = request.user)
        serialized_notif = self.serializer_class(notifications, many=True).data
        notifications.update(is_seen = True)
        return Response(serialized_notif)

    def retrieve(self, request, pk=None):
        notification = self.queryset.filter(receiver = request.user, id=pk).first()
        if notification:
            queryset = self.serializer_class(notification, many=False)
            return Response(queryset.data) 
        else:
            return Response(
                {"message":"Invalid notification request"},
                status=status.HTTP_404_NOT_FOUND
            )

class DeviceApi(APIView):
    permission_classes = (IsAuthenticated,)
    http_method_names = ['post']

    def post(self, request):
        reg_id = request.data.get("reg_id")
        if reg_id and len(reg_id):
            request.user.registerDevice(reg_id)
            return Response({}, status=status.HTTP_201_CREATED)

        return Response(
            {"message": "'reg_id' is required"}, 
            status = status.HTTP_400_BAD_REQUEST
        )


def showFirebaseJS(request):
    data='importScripts("https://www.gstatic.com/firebasejs/8.6.3/firebase-app.js");' \
         'importScripts("https://www.gstatic.com/firebasejs/8.6.3/firebase-messaging.js"); ' \
         'var firebaseConfig = {' \
         '        apiKey: "IzaSyBotNVsLYlWRTT3J0Pe5aROhqZ6250PiUc",' \
         '        authDomain: "flipo-notification.firebaseapp.com",' \
         '        databaseURL: "https://flipo-notification-default-rtdb.firebaseio.com",' \
         '        projectId: "flipo-notification",' \
         '        storageBucket: "flipo-notification.appspot.com",' \
         '        messagingSenderId: "496429988279",' \
         '        appId: "1:496429988279:web:fe5cff68df7b053cb29032",' \
         '        measurementId: "G-95VS4G1PJ2"' \
         ' };' \
         'firebase.initializeApp(firebaseConfig);' \
         'const messaging=firebase.messaging();' \
         'messaging.setBackgroundMessageHandler(function (payload) {' \
         '    console.log(payload);' \
         '    const notification=JSON.parse(payload);' \
         '    const notificationOption={' \
         '        body:notification.body,' \
         '        icon:notification.icon,' \
         '        click_action: "https//:google.com"' \
         '    };' \
         '    return self.registration.showNotification(payload.notification.title,notificationOption);' \
         '});'

    return HttpResponse(data,content_type="text/javascript")