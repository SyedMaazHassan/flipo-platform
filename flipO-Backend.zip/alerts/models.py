from django.db import models
from authentication.models import User
from django.utils import timezone
from order.models import Order, Offer
from listing.models import Product
# Create your models here.

class DeviceRegistration(models.Model):
    reg_id = models.TextField() 

    def __str__(self):
        return self.reg_id


class Notification(models.Model):
    CHOICES = [('order', 'order'), ('offer', 'offer')]
    module = models.CharField(max_length = 100, choices = CHOICES)
    receiver = models.ForeignKey(User, on_delete = models.CASCADE)
    product = models.ForeignKey(Product, on_delete = models.CASCADE, null = True, blank = True)
    offer = models.ForeignKey(Offer, on_delete = models.CASCADE, null = True, blank = True)
    order = models.ForeignKey(Order, on_delete = models.CASCADE, null = True, blank = True)
    subject = models.CharField(max_length = 200, null = True, blank = True)
    body = models.TextField()
    redirect_screen = models.CharField(max_length = 100)
    redirect_api = models.CharField(max_length = 100)
    is_seen = models.BooleanField(default = False)
    counter = models.IntegerField(default = 1)
    updated_at = models.DateTimeField(default = timezone.now)
    created_at = models.DateTimeField(default = timezone.now)


    def getJson(self):
        from alerts.serializers import NotificationSerializer
        serialized_notification = NotificationSerializer(self, many=False)
        return serialized_notification.data

    def pushNotify(self, body):
        import json
        from alerts.firebase import FirebaseNotification
        receiver_device_list = self.receiver.getDeviceList()
        subject = self.subject
        image = None
        # if self.order:
        #     image = self.order.product.thumbnail.url
        # if self.offer:
        #     image = self.offer.product.thumbnail.url

        if receiver_device_list:
            serialized_alert = json.loads(json.dumps(self.getJson()))
            push_notification = FirebaseNotification()
            push_notification.send(
                registration_ids=list(receiver_device_list),
                subject=subject,
                body=body
            )

    def socketNotify(self, body):
        from channels.layers import get_channel_layer
        from asgiref.sync import async_to_sync

        room_name = str(self.receiver.getRoomId())
        group_name = f'group_{room_name}'
        channel_layer = get_channel_layer()
        serialized_alert = self.getJson()
        async_to_sync(channel_layer.group_send)(
            group_name,
            {
                'type': 'send_notification',
                'message': serialized_alert
            }
        )


    def save(self, *args, **kwargs):
        if self.pk:
            self.updated_at = timezone.now()
        super(Notification, self).save(*args, **kwargs)


    class Meta:
        ordering = ("-updated_at",)