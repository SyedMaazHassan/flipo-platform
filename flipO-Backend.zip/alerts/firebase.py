import requests, json, os
from django.conf import settings
import firebase_admin
from firebase_admin import credentials, messaging

class FirebaseNotification:
    def __init__(self):
        self.setConfig()
        
        if not firebase_admin._apps:
            self.default_app = firebase_admin.initialize_app(self.cred)
        else:
            self.default_app = firebase_admin.get_app()
        # self.default_app.send()

    def setConfig(self):
        url = settings.BASE_DIR
        file_name = "flipo-notification-636d94efff07.json"
        file_path = os.path.join(url, file_name)
        self.cred = credentials.Certificate(file_path)

    def send(self, registration_ids , subject , body, data=None, image=None, icon=None):
        message = messaging.MulticastMessage(
            notification = messaging.Notification(
                title = subject,
                body = body,
                image = image,
            ),
            data=data,
            tokens=registration_ids
        )
        response = messaging.send_multicast(message)
        print(response.success_count)
        
        # fcm_api = "BKigmKCfPrt5MMDU48l0s-LfDqfR7VMhG3O6b1INPPPgyioy3PjPriAEuwXho4FUUVK5nLJSB9SJBVOeczwUDYQ"
        # url = "https://fcm.googleapis.com/v1/projects/myproject-b5ae1/messages:send"
        
        # headers = {
        # "Content-Type":"application/json",
        # "Authorization": 'Bearer '+fcm_api}

        # payload = {
        #     "registration_ids" :registration_ids,
        #     "priority" : "high",
        #     "notification" : {
        #         "body" : message_desc,
        #         "title" : message_title,
        #         "image" : "https://i.ytimg.com/vi/m5WUPHRgdOA/hqdefault.jpg?sqp=-oaymwEXCOADEI4CSFryq4qpAwkIARUAAIhCGAE=&rs=AOn4CLDwz-yjKEdwxvKjwMANGk5BedCOXQ",
        #         "icon": "https://yt3.ggpht.com/ytc/AKedOLSMvoy4DeAVkMSAuiuaBdIGKC7a5Ib75bKzKO3jHg=s900-c-k-c0x00ffffff-no-rj",            
        #     }
        # }

        # result = requests.post(url, data=json.dumps(payload), headers=headers)

        # print(result.content)
        # print(result.json())


