from django.shortcuts import render
from rest_framework.decorators import api_view, action
from rest_framework.response import Response
from rest_framework import status, viewsets, generics
from .serializers import *
from rest_framework.permissions import IsAuthenticated
from alerts.firebase import *
from django.http import HttpResponse


# from rest_framework_simplejwt.authentication import JWTAuthentication
def index(request):
    return render(request, "index.html")


def send(request, id):
    abc = FirebaseNotification()
    abc.send([id], "ABC title", "ABC description")
    return HttpResponse("sent")




class SocialAuth(viewsets.ModelViewSet):
    def get_queryset(self):
        return None

    @action(detail=False, methods=['post'])
    def google(self, request, pk=None):
        google_serializer = GoogleSerializer(data = request.data)
        google_serializer.is_valid(raise_exception = True)
        data = google_serializer.validated_data.get("auth_token")
        return Response(data)

    @action(detail=False, methods=['post'])
    def facebook(self, request):
        fb_serializer = FacebookSerializer(data=request.data)
        fb_serializer.is_valid(raise_exception=True)
        data = fb_serializer.validated_data.get("auth_token")
        return Response(data)


class TodoApi(viewsets.ModelViewSet):
    # permission_classes = (IsAuthenticated,)
    queryset = Todo.objects.all()
    serializer_class = TodoSerializer

    @action(detail=True, methods=['post'])
    def get_new_one(self, request, pk=None):
        print(request.user)
        return Response({})


class RegisterApiView(generics.GenericAPIView):

    serializer_class = RegisterSerializer

    def post(self, request):
        user = request.data
        serializer = self.serializer_class(data=user)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        user_data = serializer.data
        user = User.objects.get(email=user_data['email'])
        tokens = user.tokens()
        # current_site = get_current_site(request).domain
        # relativeLink = reverse('email-verify')
        # absurl = 'http://'+current_site+relativeLink+"?token="+str(token)
        # email_body = 'Hi '+user.username + \
        #     ' Use the link below to verify your email \n' + absurl
        # data = {'email_body': email_body, 'to_email': user.email,
        #         'email_subject': 'Verify your email'}

        # Util.send_email(data)
        user_data = user_data.copy()
        user_data["tokens"] = tokens
        user_data["room_id"] = user.getRoomId()
        return Response(user_data, status=status.HTTP_201_CREATED)



class LoginApiView(generics.GenericAPIView):
    serializer_class = LoginSerializer

    def post(self, request):
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)
        return Response(serializer.data, status=status.HTTP_200_OK)



class LogoutApiView(generics.GenericAPIView):
    serializer_class = LogoutSerializer
    # permission_classes = (IsAuthenticated,)
    def post(self, request):
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(status=status.HTTP_204_NO_CONTENT)