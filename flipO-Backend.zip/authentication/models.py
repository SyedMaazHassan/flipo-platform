from django.db import models
from django.utils import timezone
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin
from django.db import models
from rest_framework_simplejwt.tokens import RefreshToken
from uuid import uuid4
import json


# python manage.py migrate
# python manage.py runserver


class UserManager(BaseUserManager):
    def create_user(self, username, email, password=None):
        if username is None:
            raise TypeError('Users should have a username')
        if email is None:
            raise TypeError('Users should have a Email')

        user = self.model(username=username, email=self.normalize_email(email))
        user.set_password(password)
        user.save()
        return user

    def create_superuser(self, username, email, password=None):
        if password is None:
            raise TypeError('Password should not be none')

        user = self.create_user(username, email, password)
        user.is_superuser = True
        user.is_staff = True
        user.save()
        return user


# Create your models here.
class Todo(models.Model):
    task = models.CharField(max_length=255)
    is_done = models.BooleanField(default=False)
    created_at = models.DateTimeField(default=timezone.now)


AUTH_PROVIDERS = {'facebook': 'facebook', 'google': 'google',
                  'twitter': 'twitter', 'email': 'email'}


class User(AbstractBaseUser, PermissionsMixin):
    profile_pic = models.ImageField(upload_to="dp", default='dp/default.jpg')
    username = models.CharField(max_length=255, unique=False, db_index=True)
    phone = models.CharField(max_length=15, null = True, blank = True)
    email = models.EmailField(max_length=255, unique=True, db_index=True)
    room_id = models.UUIDField(default = uuid4)
    is_verified = models.BooleanField(default=True)
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    fcm_ids = models.ManyToManyField("alerts.DeviceRegistration") 
    favorites = models.TextField(blank=True,null=True)
    auth_provider = models.CharField(
        max_length=255, blank=False,
        null=False, default=AUTH_PROVIDERS.get('email'))

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username']

    objects = UserManager()

    def __str__(self):
        return self.email

    def getSellerProfile(self):
        seller_profile = SellerProfile.objects.filter(user = self).first()
        return seller_profile

    def getFavorites(self):
        from listing.models import Product
        existing_favorites = self.favorites
        products_ids = json.loads(existing_favorites) if existing_favorites else []
        products = Product.objects.filter(id__in = products_ids)
        return products
    
    

    def toggleFavorite(self, product_id):
        action = None
        # json.dumps -> convert list or dictionary to json string
        #  json.loads -> convert json string to list or dictionary
        existing_favorites = self.favorites
        if existing_favorites:
            existing_favorites = json.loads(existing_favorites) #[1]
        else:
            existing_favorites = [] 
        
        if product_id in existing_favorites:
            existing_favorites.remove(product_id)
            action = "removed"
        else:
            existing_favorites.append(product_id)
            action = "added"

        existing_favorites = json.dumps(existing_favorites)
        self.favorites = existing_favorites
        self.save()
        return action

    def getRoomId(self):
        room_id = str(self.room_id)
        return room_id.replace("-", "")

    def getDeviceList(self):
        return self.fcm_ids.all().values_list("reg_id", flat=True)

    def registerDevice(self, reg_id):
        check = self.fcm_ids.filter(reg_id = reg_id).exists()
        if not check:
            self.fcm_ids.create(reg_id = reg_id)

    def tokens(self):
        refresh = RefreshToken.for_user(self)
        return {
            'refresh': str(refresh),
            'access': str(refresh.access_token)
        }

class SellerProfile(models.Model):
    user = models.ForeignKey(
        "authentication.User", on_delete=models.CASCADE, related_name='seller_profile_user')
    title = models.CharField(max_length=80)
    description = models.TextField(max_length=250, null=True, blank=True)

    def __str__(self):
        return f'{self.user}'


    def getReviews(self):
        from order.models import Review
        reviews = Review.objects.filter(order__product__created_by__user=self.user)
        return reviews
    
    def getReviewSummary(self):
        reviews = self.getReviews()
        total_stars = [review.stars for review in reviews]
        if reviews:
            return sum(total_stars)/len(reviews)
        return 0
