from authentication.models import Todo, User,SellerProfile
from rest_framework import serializers
from django.contrib import auth
from rest_framework.exceptions import AuthenticationFailed
from rest_framework_simplejwt.tokens import RefreshToken, TokenError
from .google import GAuthentication
from .facebook import FBAuthentication
from .social_register import register_social_user
from django.conf import settings

class TodoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Todo
        fields = ["id", "task", "is_done"]
        # exclude = ["id"]



class GoogleSerializer(serializers.Serializer):
    auth_token = serializers.CharField()

    def validate_auth_token(self, auth_token):
        user_data = GAuthentication.validate(auth_token)
        
        try:
            user_data['sub']
        except Exception as e:
            raise serializers.ValidationError(str(e))

        if user_data['aud'] != settings.GOOGLE_CLIENT_ID:
            raise AuthenticationFailed("oops, we didn't recognize the application you are entering from.")

        user_id = user_data['sub']
        email = user_data['email']
        name = user_data['name']
        provider = 'google'

        return register_social_user(provider=provider, user_id=user_id, email=email, name=name)



class FacebookSerializer(serializers.Serializer):
    """Handles serialization of facebook related data"""
    auth_token = serializers.CharField()

    def validate_auth_token(self, auth_token):
        user_data = FBAuthentication.validate(auth_token)
        try:
            user_id = user_data['id']
            email = user_data['email']
            name = user_data['name']
            provider = 'facebook'
            return register_social_user(
                provider=provider,
                user_id=user_id,
                email=email,
                name=name
            )
        except Exception as identifier:

            raise serializers.ValidationError(
                'The token  is invalid or expired. Please login again.'
            )



class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(max_length=68, min_length=6, write_only=True)
    default_error_messages = {
        'username': 'The username should only contain alphanumeric characters'}

    def validate(self, attrs):
        email = attrs.get('email', '')
        username = attrs.get('username', '')

        if not username.isalnum():
            raise serializers.ValidationError(
                self.default_error_messages)
        return attrs

    def create(self, validated_data):
        return User.objects.create_user(**validated_data)

    class Meta:
        model = User
        fields = ['email', 'username', 'password']

class LoginSerializer(serializers.ModelSerializer):
    email = serializers.EmailField(max_length=255, min_length=3)
    password = serializers.CharField(max_length=68, min_length=6, write_only=True)
    username = serializers.CharField(max_length=255, min_length=3, read_only=True)
    tokens = serializers.SerializerMethodField()
    room_id = serializers.SerializerMethodField()

    def get_room_id(self, obj):
        user = User.objects.get(email=obj['email'])
        return user.getRoomId() 

    def get_tokens(self, obj):
        user = User.objects.get(email=obj['email'])
        tokens = user.tokens()
        return tokens

    def validate(self, attrs):
        email = attrs.get('email', '')
        password = attrs.get('password', '')
        filtered_user_by_email = User.objects.filter(email=email)
        user = auth.authenticate(email=email, password=password)

        if filtered_user_by_email.exists() and filtered_user_by_email[0].auth_provider != 'email':
            raise AuthenticationFailed(
                detail='Please continue your login using ' + filtered_user_by_email[0].auth_provider)

        if not user:
            raise AuthenticationFailed('Invalid credentials, try again')
        if not user.is_active:
            raise AuthenticationFailed('Account disabled, contact admin')
        if not user.is_verified:
            raise AuthenticationFailed('Email is not verified')

        return {
            'email': user.email,
            'username': user.username,
            'tokens': user.tokens
        }

    class Meta:
        model = User
        fields = ['email', 'password', 'username', 'tokens', 'room_id']

class LogoutSerializer(serializers.Serializer):
    refresh = serializers.CharField()
    default_error_message = {
        'bad_token': ('Token is expired or invalid')
    }

    def validate(self, attrs):
        self.token = attrs['refresh']
        return attrs

    def save(self, **kwargs):
        try:
            RefreshToken(self.token).blacklist()
        except TokenError:
            raise serializers.ValidationError(
                self.default_error_message)


class UserSerializer(serializers.ModelSerializer):
    room_id = serializers.CharField(source = 'getRoomId')
    
    class Meta:
        model = User
        fields = '__all__'


class UserShortProfile(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ["id", "profile_pic", "username"]


class UserContactProfile(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ["id", "profile_pic", "username", "phone", "email"]


class SellerProfileSerializer(serializers.ModelSerializer):
    username = serializers.SerializerMethodField('name')
    profile_pic = serializers.SerializerMethodField('pfp')
    shop_title = serializers.SerializerMethodField('shop__title')
    shop_description = serializers.SerializerMethodField('shop__description')

    def name(self, obj):
        return obj.user.username

    def pfp(self, obj):
        return obj.user.profile_pic.url

    def shop__title(self, obj):
        return obj.title

    def shop__description(self, obj):
        return obj.description
        
    class Meta:
        model = SellerProfile
        fields = ['username','profile_pic','shop_title','shop_description']