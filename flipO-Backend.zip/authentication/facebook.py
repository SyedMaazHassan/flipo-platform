import facebook
from rest_framework.exceptions import AuthenticationFailed


class FBAuthentication:
    """
    Facebook class to fetch the user info and return it
    """

    @staticmethod
    def validate(auth_token):
        """
        validate method Queries the facebook GraphAPI to fetch the user info
        """
        try:
            graph = facebook.GraphAPI(access_token=auth_token)
            profile = graph.request('/me?fields=name,email')
            return profile
        except:
            raise AuthenticationFailed("The token is either invalid or has expired. Please login again.")