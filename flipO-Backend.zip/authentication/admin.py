from django.contrib import admin
from .models import Todo, User, SellerProfile
# Register your models here.


class UserAdmin(admin.ModelAdmin):
    list_display = ['id', 'username', 'email',
                    'auth_provider', 'created_at', 'is_verified']


admin.site.register(User, UserAdmin)
admin.site.register(Todo)
admin.site.register(SellerProfile)
