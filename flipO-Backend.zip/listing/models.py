from django.db import models
from authentication.models import SellerProfile,User
from django.utils.text import slugify
import os

# These three functions define the storage location of the relative file/img fields respectively

def category_icon_directory_path(instance, filename):
    # The product pictures will be uploaded to MEDIA_ROOT/category_<id>/filename
    return 'categories/category_{0}/{1}'.format(instance.name, filename)


def product_thumbnail_directory_path(instance, filename):
    # The product pictures will be uploaded to MEDIA_ROOT/product_<id>/filename
    return 'products_thumbnails/product_{0}/{1}'.format(instance.title, filename)


def product_media_directory_path(instance, filename):
    # The product pictures will be uploaded to MEDIA_ROOT/product_<id>/filename
    return 'products_media/product_{0}/{1}'.format(instance.product.title, filename)


# Create your models here.


class Category(models.Model):
    name = models.CharField(max_length=40)
    icon = models.ImageField(upload_to="categories")

    class Meta:
        verbose_name_plural = 'Categories'

    def __str__(self):
        return self.name


class Product(models.Model):
    title = models.CharField(max_length=80)
    slug = models.SlugField(blank=True)
    thumbnail = models.ImageField(upload_to="thumbnails", verbose_name='Thumbnail')
    description = models.TextField(max_length=250, null=True, blank=True)
    category = models.ForeignKey(
        Category, on_delete=models.CASCADE, related_name='Category')
    price = models.FloatField()
    month_used = models.IntegerField()
    location = models.CharField(max_length=50)
    created_at = models.DateTimeField(auto_now_add=True)
    created_by = models.ForeignKey(
        SellerProfile, on_delete=models.CASCADE, related_name='Seller')
    is_to_ship = models.BooleanField(default=False)
    is_to_pick = models.BooleanField(default=False)
    is_published = models.BooleanField(default=False)
    is_sold_out = models.BooleanField(default=False)
    views = models.IntegerField(default=5000)

    def getOffersCount(self):
        all_orders = self.getOffers()
        return all_orders.count()

    def getOffers(self):
        all_offers = Offer.objects.filter(product = self)
        return all_offers

    # Creating the slug with the title of the product
    def save(self, *args, **kwargs):
        self.slug = slugify(self.title)
        return super().save(*args, **kwargs)

    def __str__(self):
        return self.title


class ProductMedia(models.Model):
    file = models.FileField(upload_to="products", verbose_name='Product Media')
    product = models.ForeignKey(
        Product, on_delete=models.CASCADE, related_name='Product')

    class Meta:
        verbose_name_plural = 'Product Media'

    # Categorizes if the file is a video or an image by looking at its extension
    def extension(self):
        name, extension = os.path.splitext(self.file.name)
        if extension in [".jpg", ".jpeg", ".png"]:
            return "Image"
        else:
            return "Video"

    def __str__(self):
        return f'Product {self.product.title}'


class Offer(models.Model):
    price = models.FloatField()
    note = models.TextField(max_length=250, null=True, blank=True)
    product = models.ForeignKey(
        Product, on_delete=models.CASCADE, related_name='OfferProduct')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(blank=True, null=True)
    created_by = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name='OfferUser')
    is_approved = models.BooleanField(default=False)
    is_rejected = models.BooleanField(default=False)
    is_order_placed = models.BooleanField(default=False)

    def __str__(self):
        return f'{self.price} at {self.product} by {self.created_by}'

    # to show reject


class TextSection(models.Model):
    name = models.CharField(max_length=250)

    def __str__(self):
        return self.name

class TextTypeChoices(models.TextChoices):
    MAIN_HEADING = 'Main Heading'
    SUB_HEADING = "Sub Heading"
    NORMAL_TEXT = "Normal Text"

class Text(models.Model):
    content_id = models.CharField(max_length=200,unique=True,primary_key=True)
    content = models.TextField()
    text_type = models.CharField(max_length=30,choices=TextTypeChoices.choices,default=TextTypeChoices.NORMAL_TEXT)
    section = models.ForeignKey(TextSection, on_delete=models.CASCADE)

    def __str__(self):
        return self.content


## Search Model

class SearchHistory(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    query  = models.CharField(max_length=75)
    created_at = models.DateTimeField(auto_now_add=True)
    section = models.CharField(max_length=25)

    def __str__(self):
        return f'{self.user} searched for {self.query} ({self.section} section)'