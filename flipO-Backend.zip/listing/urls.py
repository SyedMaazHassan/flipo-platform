from django.urls import path, include
from .views import *
from rest_framework.routers import DefaultRouter

router = DefaultRouter(trailing_slash=False)
router.register('products', ProductView, basename='products')
router.register('categories', CategoryView, basename='categories')
router.register('medias', ProductMediaView, basename='medias')
router.register('offer', OfferView, basename='offer')
router.register('text', TextView, basename='text')
router.register('search', SearchView, basename='search')

urlpatterns = [
    path("", include(router.urls)),
    path("my_products",MyProductsView.as_view(),name='my_products'),
]
