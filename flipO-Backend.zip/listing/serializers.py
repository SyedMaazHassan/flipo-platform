from rest_framework import serializers
from .models import *
from django.utils import timezone
from django.contrib.humanize.templatetags import humanize
from authentication.serializers import  SellerProfileSerializer, UserShortProfile

class CategorySerializer(serializers.ModelSerializer):
    icon = serializers.SerializerMethodField('icon_url')

    def icon_url(self, obj):
        return obj.icon.url

    class Meta:
        model = Category
        fields = ["id", 'name', 'icon']


class ProductShortSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = ['id', 'title', 'thumbnail', 'price', 'created_at']

class ProductSerializer(serializers.ModelSerializer):
    created_by = SellerProfileSerializer(many=False)
    category = CategorySerializer(many=False)
    thumbnail = serializers.SerializerMethodField("thumbnail_url")
    is_mine = serializers.SerializerMethodField("is_mine_field")
    views = serializers.SerializerMethodField("humanize_views")
    created_at = serializers.SerializerMethodField('humanize_created_at')
    review = serializers.SerializerMethodField("seller_review")

    def seller_review(self,obj):
        seller = obj.created_by
        return seller.getReviewSummary() 

    def humanize_created_at(self,obj):
        return humanize.naturaltime(obj.created_at)

    def humanize_views(self,obj):
        views = obj.views
        magnitude = 0
        while abs(views) >= 1000:
            magnitude+=1
            views /= 1000
        return '%.2f%s' % (views, ['', 'K', 'M', 'G', 'T', 'P'][magnitude])
    
    def is_mine_field(self,obj):
        user = self.context.get("user")
        if user:
            return user == obj.created_by.user
        return False

    def thumbnail_url(self, obj):
        return obj.thumbnail.url

    class Meta:
        model = Product
        fields = ['id', 'title', 'slug','description', 'thumbnail',
                  'category', 'price', 'month_used', 'created_by', 'created_at',
                  "is_to_ship", "is_to_pick", "is_published","is_mine",'views','review']

class OfferProductSerializer(serializers.ModelSerializer):
    offer_count = serializers.SerializerMethodField("offer_count_method")
    category = CategorySerializer(many=False)
    review = serializers.SerializerMethodField("seller_review")

    def seller_review(self,obj):
        seller = obj.created_by
        return seller.getReviewSummary() 

    def offer_count_method(self,obj):
        return len(Offer.objects.filter(product=obj))
        
    class Meta:
        model = Product
        fields = ['id', 'title', 'thumbnail', 'price','offer_count',"category",'review']


class OfferSerializer(serializers.ModelSerializer):
    created_by = UserShortProfile(many=False)
    status = serializers.SerializerMethodField("set_status")
    show_rejected = serializers.SerializerMethodField("to_show_rejected")
    created_at = serializers.SerializerMethodField('humanize_created_at')
    updated_at = serializers.SerializerMethodField('humanize_updated_at')
    
    def humanize_updated_at(self,obj):
        return humanize.naturaltime(obj.updated_at)

    def humanize_created_at(self,obj):
        return humanize.naturaltime(obj.created_at)

    def to_show_rejected(self,obj):
        if obj.updated_at:
            time_diff = timezone.now() - obj.updated_at
            time_diff_in_hrs = (time_diff.seconds/60)/60
            if obj.is_approved and not obj.is_order_placed and time_diff_in_hrs < 24:
                return True
        return False

    def set_status(self,obj):
        if obj.is_rejected:
            return "REJECTED"
        else:
            if obj.is_approved:
                return "ACCEPTED"
            else:
                return "PENDING"

    class Meta:
        model = Offer
        fields = ['id',"price","note","product",
                    "is_approved",'is_rejected',"created_by",
                        "created_at","updated_at","status","show_rejected",]


class BuyerOfferProductSerializer(serializers.ModelSerializer):
    category = CategorySerializer(many=False)
    review = serializers.SerializerMethodField("seller_review")

    def seller_review(self,obj):
        seller = obj.created_by
        return seller.getReviewSummary()

    class Meta:
        model = Product
        fields = ['id','title','thumbnail','price',"category",'review']

class BuyerOfferSerializer(serializers.ModelSerializer):
    product = BuyerOfferProductSerializer(many=False)
    status = serializers.SerializerMethodField("set_status")

    def set_status(self,obj):
        if obj.is_rejected:
            return "REJECTED"
        else:
            if obj.is_approved:
                return "ACCEPTED"
            else:
                return "PENDING"
    
    class Meta:
        model = Offer
        fields = ['id',"price","note","product","is_approved",'is_rejected',"created_at","updated_at","status"]

class ProductMediaSerializer(serializers.ModelSerializer):
    media_type = serializers.SerializerMethodField('type_media')

    def type_media(self, obj):
        return obj.extension()

    class Meta:
        model = ProductMedia
        fields = ["id", 'file', 'product', 'media_type']

class MyProductSerializer(serializers.ModelSerializer):
    created_by = SellerProfileSerializer(many=False)
    category = CategorySerializer(many=False)
    class Meta:
        model = Product
        fields = ['id', 'title', 'slug', 'thumbnail',
                  'category', 'price', 'month_used', 'created_by',
                  "is_to_ship", "is_to_pick", "is_published"]

class TextSerializer(serializers.ModelSerializer):
    class Meta:
        model = Text
        fields = "__all__"