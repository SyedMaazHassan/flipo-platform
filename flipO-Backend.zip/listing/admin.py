from django.contrib import admin
from .models import *

# Register your models here.


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('id','title', 'price','views','description', 'category',
                    'month_used', 'is_sold_out', 'created_by')

    list_editable = ['price','views']


@admin.register(Offer)
class OfferAdmin(admin.ModelAdmin):
    list_display = ('id','price', 'note', 'product', 'created_at', 'created_by')

@admin.register(Text)
class TextAdmin(admin.ModelAdmin):
    list_display = ('content_id','content', 'text_type', 'section')

admin.site.register((Category, ProductMedia,TextSection,SearchHistory))
