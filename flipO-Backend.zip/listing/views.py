from rest_framework.viewsets import ModelViewSet
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticatedOrReadOnly, IsAuthenticated,IsAdminUser
from rest_framework import status
from rest_framework.views import APIView
from rest_framework.decorators import action
from .models import *
from .serializers import *
from .pagination import MyPageNumberPagination
from alerts.notification import sendNotification
from .filters import ProductFilter,OfferFilter
from django.utils import timezone
import time
from django.db.models import Q

class ProductView(ModelViewSet):
    queryset = Product.objects.all().order_by("-id")
    serializer_class = ProductSerializer
    http_method_names = ['get','patch','delete','post']
    permission_classes = [IsAuthenticatedOrReadOnly,]
    pagination_class = MyPageNumberPagination
    filterset_class = ProductFilter

    error_status = status.HTTP_400_BAD_REQUEST
    output_data_for_error = {"message": None}
    

    def list(self, request):
        is_mine = bool(request.query_params.get("is_mine"))
        all_products = self.queryset

        # Check if only "My products" are required
        if is_mine:
            if request.user.is_authenticated:
                seller_profile = request.user.getSellerProfile()
                all_products = all_products.filter(created_by = seller_profile)

        # Filter results as per ProductFilter
        results = self.filter_queryset(all_products)

        # Get paginated queryset
        results = self.paginate_queryset(results)

        # Serializing queryset
        serialized_products = self.serializer_class(results, many=True, context = {"user": request.user})

        # Returning response in pagination response
        return self.get_paginated_response(serialized_products.data)
    


    def create(self, request):
        title = request.data.get("title")
        category_id = request.data.get("category_id")
        price = request.data.get("price")
        month_used = request.data.get("month_used")
        location = request.data.get("location")
        thumbnail = request.data.get("thumbnail")
        is_to_ship = request.data.get("is_to_ship")
        is_to_pick = request.data.get("is_to_pick")
        description = request.data.get("description")

        if not title or not category_id or not price or not month_used or not location or not thumbnail:
            self.output_data_for_error['message'] = "Missing required information for product creation"
            return Response(self.output_data_for_error, self.error_status)

        category = Category.objects.filter(id=category_id).first()
        if not category:
            self.output_data_for_error['message'] = "Category with this id does not exist"
            return Response(self.output_data_for_error, self.error_status)
        
        created_by = SellerProfile.objects.filter(user=request.user).first()
        if not category:
            self.output_data_for_error['message'] = "The current user does not have a seller profile."
            return Response(self.output_data_for_error, self.error_status)


        
        product = Product.objects.create(title=title,
                category=category,price=price,month_used=month_used,location=location,
                thumbnail=thumbnail,created_by=created_by)

        is_to_ship = True if is_to_ship == "true" else False
        if is_to_ship: product.is_to_ship=is_to_ship
        
        is_to_pick = True if is_to_pick == "true" else False
        if is_to_pick: product.is_to_pick=is_to_pick
        
        if description: product.description=description

        product.save()

        serializer = ProductSerializer(product)

        return Response(serializer.data)
        
    def partial_update(self, request,pk):
        product = Product.objects.filter(id=pk).first()

        if not product:
            self.output_data_for_error['message'] = "Product with this id does not exist"
            return Response(self.output_data_for_error, self.error_status)

        if product.created_by.user != request.user:
            self.output_data_for_error['message'] = "You are not the seller of this product"
            return Response(self.output_data_for_error, self.error_status)
        
        if product.is_sold_out:
            self.output_data_for_error['message'] = "The product is now sold so you can not update it"
            return Response(self.output_data_for_error, self.error_status)
        
        serializer = ProductSerializer(product, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)

    def destroy(self, request,pk):
        product = Product.objects.filter(id=pk).first()

        if not product:
            self.output_data_for_error['message'] = "Product with this id does not exist"
            return Response(self.output_data_for_error, self.error_status)

        if product.created_by.user != request.user:
            self.output_data_for_error['message'] = "You are not the seller of this product"
            return Response(self.output_data_for_error, self.error_status)

        if product.is_sold_out:
            self.output_data_for_error['message'] = "The product is now sold so you can not delete it"
            return Response(self.output_data_for_error, self.error_status)

        product.delete()
        return Response({"message": "Product deleted successfully"},
                        status=status.HTTP_204_NO_CONTENT)
    
    @action(detail=True,methods=['patch'])
    def toggleFavorite(self,request,pk):
        user = request.user
        product = Product.objects.filter(id=pk).first()
        if not product:
            self.output_data_for_error['message'] = "Product with this id does not exist"
            return Response(self.output_data_for_error, self.error_status)
        
        if product.created_by.user == user:
            self.output_data_for_error['message'] = "You can not favorite your own product"
            return Response(self.output_data_for_error, self.error_status)
        
        action = user.toggleFavorite(product_id=pk)
        return Response({"action":action})
       
        
    @action(detail=False,methods=['get'])
    def getFavorites(self,request):
        user=request.user
        favorite_products = user.getFavorites()
        serializer = ProductSerializer(favorite_products,many=True)
        return Response(serializer.data)


    @action(detail=True, methods=['patch'])
    def launch(self, request, pk):
        product = Product.objects.filter(id=pk).first()

        if "is_published" not in list(request.data.keys()) or len(request.data.keys()) != 1:
            self.output_data_for_error['message'] = "Only one parameter is allowed which is 'is_published'"
            return Response(self.output_data_for_error, self.error_status)


        if not product:
            self.output_data_for_error['message'] = "Product with this id does not exist"
            return Response(self.output_data_for_error, self.error_status)

        if product.created_by.user != request.user:
            self.output_data_for_error['message'] = "You are not the seller of this product"
            return Response(self.output_data_for_error, self.error_status)


        serializer = ProductSerializer(
            product, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)

class CategoryView(ModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    http_method_names = ['get']

class ProductMediaView(ModelViewSet):
    queryset = ProductMedia.objects.all()
    serializer_class = ProductMediaSerializer
    permission_classes = [IsAuthenticatedOrReadOnly]
    error_status = status.HTTP_400_BAD_REQUEST
    output_data_for_error = {"message": None}

    # No Update Method
    http_method_names = ["get", 'delete','post']

    def list(self,request):
        if "product_id" in list(request.query_params):
            product_id = request.query_params['product_id']
            product = Product.objects.filter(id=product_id).first()
            if not product:
                self.output_data_for_error['message'] = "Product with this id does not exist"
                return Response(self.output_data_for_error, self.error_status)
            medias = self.queryset.filter(product=product)
        else:
            medias = self.queryset
        serializer = ProductMediaSerializer(medias,many=True)
        return Response(serializer.data)
    
    def create(self,request):
        product_id = request.data.get("product_id")
        product = Product.objects.filter(id=product_id).first()
        if not product:
            self.output_data_for_error['message'] = "Product with this id does not exist"
            return Response(self.output_data_for_error, self.error_status)
        if product.created_by.user != request.user:
            self.output_data_for_error['message'] = "You are not the seller of this product"
            return Response(self.output_data_for_error, self.error_status)
        
        file = dict(request.data.lists())['file']
        if len(file) == 1:
            media = ProductMedia.objects.create(product=product, file=file[0])
            serializer = ProductMediaSerializer(media)
            return Response(serializer.data)
        else:
            for f in file:
                ProductMedia.objects.create(product=product, file=f)
            return Response({"message": "Success"})

    def destroy(self,request,pk):
        media = ProductMedia.objects.filter(id=pk).first()
        if not media:
            self.output_data_for_error['message'] = "Media with this id does not exist"
            return Response(self.output_data_for_error, self.error_status)
        if media.product.created_by.user != request.user:
            self.output_data_for_error['message'] = "You are not the seller of the product of the given media"
            return Response(self.output_data_for_error, self.error_status)
        media.delete()
        return Response({"message": "Media deleted successfully"},
                        status=status.HTTP_204_NO_CONTENT)

class OfferView(ModelViewSet):
    queryset = Offer.objects.all()
    serializer_class = OfferSerializer
    permission_classes = [IsAuthenticated, ]
    http_method_names = ['get', 'delete', 'post', "patch"]
    filterset_class = OfferFilter

    error_status = status.HTTP_400_BAD_REQUEST
    output_data_for_error = {"message": None}

    def list(self, request):
        if "product_id" in list(request.query_params):
            product_id = request.query_params['product_id']
            product = Product.objects.filter(id=product_id).first()
            if not product:
                self.output_data_for_error['message'] = "Product with this id does not exist"
                return Response(self.output_data_for_error, self.error_status)
            if product.created_by.user != request.user:
                self.output_data_for_error['message'] = "You are not the product owner so you can not see the offers of this product"
                return Response(self.output_data_for_error, self.error_status)
            offers = self.queryset.filter(product=product,is_rejected=False)
            offers = self.filter_queryset(offers)
            serializer = OfferSerializer(offers, many=True)
            return Response(serializer.data)

        offers = self.queryset.filter(created_by=request.user,is_rejected=False)
        offers = self.filter_queryset(offers)
        serializer = BuyerOfferSerializer(offers, many=True)
        return Response(serializer.data)

    def retrieve(self, request, pk=None):
        return Response({"message": "Retrieve method disabled"},
                        status=status.HTTP_400_BAD_REQUEST)

    def create(self, request, *args, **kwargs):
        product_id = request.data.get('product_id')
        price = request.data.get('price')
        note = request.data.get('note')

        if not product_id:
            self.output_data_for_error['message'] = "Please provide a product id to place an offer on."
            return Response(self.output_data_for_error, self.error_status)

        product = Product.objects.filter(id=product_id).first()
        if not product:
            self.output_data_for_error['message'] = "Product with this id does not exist"
            return Response(self.output_data_for_error, self.error_status)

        if not price:
            self.output_data_for_error['message'] = "You must provide a price to your offer"
            return Response(self.output_data_for_error, self.error_status)

        if product.created_by.user == request.user:
            self.output_data_for_error['message'] = "You can not post an offer to your own product"
            return Response(self.output_data_for_error, self.error_status)

        if Offer.objects.filter(
                created_by=request.user, product=product).first():
            self.output_data_for_error['message'] = "You can only post a single offer to a product"
            return Response(self.output_data_for_error, self.error_status)

        offer = Offer.objects.create(
            price=price, product=product, created_by=request.user)

        if note:
            offer.note = note

        offer.save()

        sendNotification(
            subject="New offer received",
            body=f"{offer.created_by.username} has submitted an offer of ${offer.price} for your product '{product.title}'",
            receiver=product.created_by.user,
            receiver_type="seller",
            redirect_screen="offer",
            redirect_api=f"/offer?product_id={product_id}",
            username=offer.created_by.username,
            product=product,
            offer=offer
        )
        serializer = OfferSerializer(offer)
        return Response(serializer.data)

    def partial_update(self, request, pk):
        offer = Offer.objects.filter(id=pk).first()
        is_approved = request.data.get("is_approved")

        if not offer:
            self.output_data_for_error['message'] = "Offer with this id does not exist"
            return Response(self.output_data_for_error, self.error_status)
        if offer.created_by != request.user:
            self.output_data_for_error['message'] = "You did not create this offer so you can not update it"
            return Response(self.output_data_for_error, self.error_status)
        if offer.is_approved:
            self.output_data_for_error['message'] = "This offer is approved now so you can not update it"
            return Response(self.output_data_for_error, self.error_status)
        if is_approved:
            self.output_data_for_error['message'] = "You can not update the is_approved parameter"
            return Response(self.output_data_for_error, self.error_status)
        serializer = OfferSerializer(offer, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)

    def destroy(self, request, pk):
        offer = Offer.objects.filter(id=pk).first()

        if not offer:
            self.output_data_for_error['message'] = "Offer with this id does not exist"
            return Response(self.output_data_for_error, self.error_status)
        if offer.created_by != request.user:
            self.output_data_for_error['message'] = "You did not create this offer so you can not delete it"
            return Response(self.output_data_for_error, self.error_status)
        if offer.is_approved:
            self.output_data_for_error['message'] = "This offer is approved now so you can not delete it"
            return Response(self.output_data_for_error, self.error_status)

        offer.delete()
        return Response({"message": "Offer deleted successfully"},
                        status=status.HTTP_204_NO_CONTENT)

    @action(detail=True, methods=['patch'])
    def accept(self, request, pk):
        offer = Offer.objects.filter(id=pk).first()

        if not offer:
            self.output_data_for_error['message'] = "Offer with this id does not exist"
            return Response(self.output_data_for_error, self.error_status)

        if offer.created_by == request.user:
            self.output_data_for_error['message'] = "You can not accept your own offer"
            return Response(self.output_data_for_error, self.error_status)

        if not offer.product.created_by.user == request.user:
            self.output_data_for_error['message'] = "You can not accept this offer as you are the owner of the product in the offer."
            return Response(self.output_data_for_error, self.error_status)
        if offer.is_approved:
            self.output_data_for_error['message'] = "The offer is already accepted"
            return Response(self.output_data_for_error, self.error_status)
        
        offer.is_approved = True
        offer.is_rejected = False
        offer.updated_at = timezone.now()
        offer.save()

        serializer = OfferSerializer(offer,many=False)

        return Response(serializer.data)
    
    @action(detail=True, methods=['patch'])
    def reject(self, request, pk):
        offer = Offer.objects.filter(id=pk).first()
        

        if not offer:
            self.output_data_for_error['message'] = "Offer with this id does not exist"
            return Response(self.output_data_for_error, self.error_status)

        if offer.created_by == request.user:
            self.output_data_for_error['message'] = "You can not accept your own offer"
            return Response(self.output_data_for_error, self.error_status)

        if not offer.product.created_by.user == request.user:
            self.output_data_for_error['message'] = "You can not accept this offer as you are the owner of the product in the offer."
            return Response(self.output_data_for_error, self.error_status)
        if offer.is_rejected or not offer.is_approved:
            self.output_data_for_error['message'] = "The offer is already rejected or is not accepted in the first place."
            return Response(self.output_data_for_error, self.error_status)
        
    
        time_diff = timezone.now()-offer.updated_at
        time_diff_in_hrs = (time_diff.seconds/60)/60

        if time_diff_in_hrs < 24:
            self.output_data_for_error['message'] = "24 hours have not been passed since the offer is accepted , until then you can not reject the offer."
            return Response(self.output_data_for_error, self.error_status)

        
        offer.is_rejected = True
        offer.is_approved = False
        offer.save()
        serializer = OfferSerializer(offer,many=False)

        return Response(serializer.data)
    
    @action(detail=False,methods=['get'])
    def group(self,request):
        created_by = SellerProfile.objects.filter(user=request.user).first()
        if not created_by:
            self.output_data_for_error['message'] = "You are not a seller"
            return Response(self.output_data_for_error, self.error_status)

        # is_published=True --> this must also be added 
        my_products = Product.objects.filter(created_by=created_by,is_sold_out=False)

        products = []
        for product in my_products:
            if len(Offer.objects.filter(product=product,is_rejected=False)) != 0:
                products.append(product) 
            
        serializer = OfferProductSerializer(products,many=True)
        return Response(serializer.data)

class MyProductsView(APIView):
    error_status = status.HTTP_400_BAD_REQUEST
    output_data_for_error = {"message": None}
    def get(self,request):
        if not request.user.is_authenticated:
            self.output_data_for_error['message'] = "You are not logged in"
            return Response(self.output_data_for_error, self.error_status)
        created_by = SellerProfile.objects.filter(user=request.user).first()
        if not created_by:
            self.output_data_for_error['message'] = "You are not a seller"
            return Response(self.output_data_for_error, self.error_status)
        my_products = Product.objects.filter(created_by=created_by)
        if len(my_products)==0:
            self.output_data_for_error['message'] = "You dont have any products as of yet."
            return Response(self.output_data_for_error, self.error_status)
        print(my_products)
        serializer = MyProductSerializer(my_products,many=True)
        return Response(serializer.data)

class SearchView(ModelViewSet):
    queryset = SearchHistory.objects.all()
    http_method_names =['get']
    error_status = status.HTTP_400_BAD_REQUEST
    output_data_for_error = {"message": None}

    def list(self,request):
        if "query" not in list(request.query_params):
            self.output_data_for_error['message'] = "You must provide query"
            return Response(self.output_data_for_error, self.error_status)

        query = request.query_params['query']
        section = "products"

        if "section" in list(request.query_params):
            section = request.query_params['section']

        # Searching in products 
        if section == "products":
            results = Product.objects.filter(Q(title__icontains=query)|Q(description__icontains=query))
            serializer = ProductSerializer(results,many=True)

            if request.user.is_authenticated:
                search_history = SearchHistory(user=request.user,query=query,section=section)
                search_history.save()
            
            return Response(serializer.data)

        # Searching in offers
        if section == "offers":
            results = Offer.objects.filter(Q(note__icontains=query)|Q(price__icontains=query))
            serializer = OfferSerializer(results,many=True)

            if request.user.is_authenticated:
                search_history = SearchHistory(user=request.user,query=query,section=section)
                search_history.save()

            return Response(serializer.data)






# Only Admins can access this view
class TextView(ModelViewSet):
    queryset = Text.objects.all()
    serializer_class = TextSerializer
    permission_classes = [IsAdminUser,]
    http_method_names = ['get']

    error_status = status.HTTP_400_BAD_REQUEST
    output_data_for_error = {"message": None}

    def list(self,request):
        if "section" not in list(request.query_params):
            self.output_data_for_error['message'] = "You must provide section"
            return Response(self.output_data_for_error, self.error_status)
        section = request.query_params['section']
        texts = Text.objects.filter(section__name=section)
        if len(texts)==0:
            self.output_data_for_error['message'] = "There are no texts with this section"
            return Response(self.output_data_for_error, self.error_status)
        serializer = TextSerializer(texts,many=True)
        return Response(serializer.data)

    def retrieve(self, request, pk):
        text = Text.objects.filter(pk=pk).first()
        if not text:
            self.output_data_for_error['message'] = "There are no texts with this content id"
            return Response(self.output_data_for_error, self.error_status)
        serializer = TextSerializer(text,many=False)
        return Response(serializer.data)
        



        